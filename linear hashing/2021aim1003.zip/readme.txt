
Instruction to execute linear hashing.
Note : first insure that there is no file of hashing present in current directory.
        (like : 1.txt,2.txt,1_OV_1.txt).
-> 1. gcc .\data_generator.c
-> 2. .\a.exe (for windows)
        (above 2 step,will create random data )
-> 3. gcc .\linear_hashing.c
-> 4. .\a.exe 
        -> Enter the value of B(number of record in bucket).
        -> Enter '1' for visualization otherwise Enter '2'.
        -> Then it will compute linear hashing 
        -> Enter the record id you want to search.
        -> Enter '1' to continue search otherwise Enter '0'.